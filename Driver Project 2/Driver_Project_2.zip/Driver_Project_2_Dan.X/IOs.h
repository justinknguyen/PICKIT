#ifndef IOS_H
#define	IOS_H

void IOinit();
void IOcheck();

#endif	/* IOS_H */