#ifndef TIMERS_H
#define	TIMERS_H

void Delay_ms(uint16_t);

#endif	/* TIMERS.H */