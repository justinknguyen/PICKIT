#ifndef Voltage_H
#define	Voltage_H

void VoltageCheck();

#endif	/* Voltage_H */