#ifndef ADC_H
#define	ADC_H

uint16_t ADC();

#endif	/* ADC_H */