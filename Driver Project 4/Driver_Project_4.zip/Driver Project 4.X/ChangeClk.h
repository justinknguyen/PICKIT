#ifndef CHANGECLK_H
#define	CHANGECLK_H

void NewClk(unsigned int);

#endif	/* CHANGECLK_H */