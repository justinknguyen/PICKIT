#ifndef IOS_H
#define	IOS_H

void IOinit();
void IOCheck();

#endif	/* IOS_H */