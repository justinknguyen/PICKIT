#ifndef STOPWATCH_H
#define	STOPWATCH_H

void Countdown();
void Timer();
void ReactionGame();

#endif	/* IOS_H */