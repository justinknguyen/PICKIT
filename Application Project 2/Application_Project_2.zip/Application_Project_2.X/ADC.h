#ifndef ADC_H
#define	ADC_H

uint16_t ADC(int);

#endif	/* ADC_H */