#ifndef Frequency_H
#define	Frequency_H

void FrequencyCheck();

#endif	/* Frequency_H */