#ifndef Resistance_H
#define	Resistance_H

void ResistanceCheck();

#endif	/* Resistance_H */