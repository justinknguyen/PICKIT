#ifndef Capacitance_H
#define	Capacitance_H

void CapacitanceCheck();

#endif	/* Capacitance_H */