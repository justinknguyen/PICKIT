#ifndef BarGraph_H
#define	BarGraph_H

void BarGraph(uint32_t);

#endif	/* BarGraph_H */