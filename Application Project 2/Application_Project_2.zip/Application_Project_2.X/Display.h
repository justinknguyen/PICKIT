#ifndef Display_H
#define	Display_H

void DisplayVoltage(float);
void DisplayOhms(float);
void DisplayCapacitance(double);
void DisplayFrequency(double);
void DisplayNoFrequency();

#endif	/* Display_H */